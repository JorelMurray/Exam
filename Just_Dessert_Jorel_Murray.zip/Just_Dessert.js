function addLikes(element){
    count = document.querySelector(element)
    count.innerHTML++;
}

function goSearch () {

    let item = document.getElementById("searchbar").value
    alert("You are searching for " + item)
}